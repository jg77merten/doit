<?php
interface FinalView_Grid_Field_Decorator_Interface
{
    public function render($row, $fieldName);
}