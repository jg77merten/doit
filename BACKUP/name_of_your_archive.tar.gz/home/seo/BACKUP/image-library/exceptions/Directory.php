<?php

class ImageLibrary_Exception_Directory extends Exception
{ }