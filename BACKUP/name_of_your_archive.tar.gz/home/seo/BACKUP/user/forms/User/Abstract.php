<?php

abstract class User_Form_User_Abstract extends Zend_Form
{

}