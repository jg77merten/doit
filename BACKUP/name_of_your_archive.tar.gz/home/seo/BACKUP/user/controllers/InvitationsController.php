<?php

class User_InvitationsController extends FinalView_Controller_Action {

    function indexAction()
    {
        
    }

}