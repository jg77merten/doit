<?php

class User_Auth_Exception extends FinalView_Auth_Exception 
{}